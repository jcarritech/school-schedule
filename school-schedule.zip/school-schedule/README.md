# School Schedule Website

A free website showing **teacher**, **student**, and **section** schedules.
It runs on GitHub Pages and updates itself whenever you edit the schedule data.

## What it does

- Pick a teacher, student, or section and see their weekly timetable.
- Shows today's classes and highlights the class happening right now.
- Flags double-booked teachers, rooms, and sections.
- Works on phones, supports dark mode, and has a Print button.

## Put it online (one-time setup)

1. Create a new repository on GitHub (for example `school-schedule`). Public is fine for the free plan.
2. Upload all files from this folder to the repository, keeping the folder structure
   (`index.html`, `app.js`, `style.css`, `data/`, `scripts/`, `.github/`).
   On github.com: **Add file → Upload files**, then drag the files in. The `.github` folder is hidden on some systems, so
   make sure it is included.
3. Open **Settings → Pages**. Under **Build and deployment → Source**, choose **GitHub Actions**.
4. Open the **Actions** tab. The "Validate and deploy schedule site" workflow runs on its own.
   When it turns green, your site is live at `https://YOUR-USERNAME.github.io/school-schedule/`.

## Updating schedules (the automated part)

All schedules live in one file: `data/schedule.json`.

1. On GitHub, open `data/schedule.json` and click the pencil icon (Edit).
2. Change names, times, rooms, or add classes. Commit the change.
3. GitHub automatically checks the file and redeploys. If you made a mistake
   (a typo in an ID, a bad time, or two classes in the same room at the same time),
   the check fails, the site keeps showing the last good version, and the Actions tab tells you what to fix.

### File format

```json
{
  "teachers": [{ "id": "t1", "name": "Ms. Reyes", "subject": "Mathematics" }],
  "sections": [{ "id": "s1", "name": "Grade 7 - Rizal" }],
  "students": [{ "id": "st1", "name": "Ana Dela Cruz", "sectionId": "s1" }],
  "classes": [
    {
      "subject": "Mathematics",
      "teacherId": "t1",
      "sectionId": "s1",
      "room": "101",
      "days": ["Mon", "Wed", "Fri"],
      "start": "08:00",
      "end": "09:00"
    }
  ]
}
```

- Times use 24-hour format, like `13:30`.
- A student sees the schedule of the section they belong to.
- One class entry can list several days, so you do not repeat it.

## Try it on your computer first (optional)

Browsers block loading data files from `file://`, so use a tiny local server:

```
python3 -m http.server
```

Then open http://localhost:8000.

## Check the data without deploying

```
node scripts/validate.js
```

## Privacy note

GitHub Pages sites are public. The sample data uses made-up names. Before adding real student names,
consider using a private repository (GitHub Pages for private repos needs a paid plan) or showing sections only.
