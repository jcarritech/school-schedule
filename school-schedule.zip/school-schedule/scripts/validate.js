// Validates data/schedule.json. Run by GitHub Actions before every deploy:
//   node scripts/validate.js
// Exits with an error (and blocks the deploy) if the data is invalid or has double-bookings.
const fs = require("fs");
const path = require("path");

const file = path.join(__dirname, "..", "data", "schedule.json");
let data;
try {
  data = JSON.parse(fs.readFileSync(file, "utf8"));
} catch (e) {
  console.error(`schedule.json is not valid JSON: ${e.message}`);
  process.exit(1);
}

const errors = [];
const timeRe = /^([01]\d|2[0-3]):[0-5]\d$/;
const toMin = (t) => { const [h, m] = t.split(":").map(Number); return h * 60 + m; };
const ids = (list) => new Set((list || []).map((x) => x.id));

const teacherIds = ids(data.teachers);
const sectionIds = ids(data.sections);
const days = data.days || [];

(data.students || []).forEach((s) => {
  if (!sectionIds.has(s.sectionId)) errors.push(`Student "${s.name}" has unknown sectionId "${s.sectionId}"`);
});

const sessions = [];
(data.classes || []).forEach((c, i) => {
  const label = `Class #${i + 1} (${c.subject})`;
  if (!teacherIds.has(c.teacherId)) errors.push(`${label}: unknown teacherId "${c.teacherId}"`);
  if (!sectionIds.has(c.sectionId)) errors.push(`${label}: unknown sectionId "${c.sectionId}"`);
  if (!timeRe.test(c.start) || !timeRe.test(c.end)) {
    errors.push(`${label}: start/end must look like "08:30"`);
    return;
  }
  if (toMin(c.end) <= toMin(c.start)) errors.push(`${label}: end must be after start`);
  (c.days || []).forEach((d) => {
    if (!days.includes(d)) errors.push(`${label}: unknown day "${d}" (allowed: ${days.join(", ")})`);
    sessions.push({ ...c, day: d, label });
  });
});

for (let i = 0; i < sessions.length; i++) {
  for (let j = i + 1; j < sessions.length; j++) {
    const a = sessions[i], b = sessions[j];
    if (a.day !== b.day) continue;
    if (!(toMin(a.start) < toMin(b.end) && toMin(b.start) < toMin(a.end))) continue;
    const why = [];
    if (a.teacherId === b.teacherId) why.push(`teacher ${a.teacherId}`);
    if (a.room === b.room) why.push(`room ${a.room}`);
    if (a.sectionId === b.sectionId) why.push(`section ${a.sectionId}`);
    if (why.length) errors.push(`Conflict on ${a.day} ${a.start}: ${a.label} vs ${b.label} share ${why.join(", ")}`);
  }
}

if (errors.length) {
  console.error(`Found ${errors.length} problem(s):`);
  errors.forEach((e) => console.error(` - ${e}`));
  process.exit(1);
}
console.log(`OK: ${data.teachers.length} teachers, ${data.sections.length} sections, ${data.students.length} students, ${sessions.length} weekly sessions, no conflicts.`);
